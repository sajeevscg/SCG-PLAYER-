package com.scg.player

import android.util.Base64
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Playlist import. Spotify and YouTube use their official APIs with the user's own keys
 * (entered in Settings). JioSaavn has no public API, so it is imported from a pasted list / CSV.
 * Only track metadata (title + artist) is fetched; no audio is downloaded.
 */
object Importer {

    private fun http(url: String, headers: Map<String, String> = emptyMap(), body: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 20_000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IOException("HTTP $code ${text.take(160)}")
        return text
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    // ---------- Spotify ----------
    fun spotify(link: String, clientId: String, clientSecret: String): ImportedPlaylist {
        require(clientId.isNotBlank() && clientSecret.isNotBlank()) {
            "Add your Spotify Client ID and Secret in Settings first."
        }
        val pid = Regex("playlist[/:]([A-Za-z0-9]+)").find(link)?.groupValues?.get(1)
            ?: throw IllegalArgumentException("That doesn't look like a Spotify playlist link.")
        val basic = Base64.encodeToString("$clientId:$clientSecret".toByteArray(), Base64.NO_WRAP)
        val token = JSONObject(
            http(
                "https://accounts.spotify.com/api/token",
                mapOf(
                    "Authorization" to "Basic $basic",
                    "Content-Type" to "application/x-www-form-urlencoded"
                ),
                "grant_type=client_credentials"
            )
        ).getString("access_token")
        val auth = mapOf("Authorization" to "Bearer $token")

        val name = JSONObject(http("https://api.spotify.com/v1/playlists/$pid?fields=name", auth))
            .optString("name", "Spotify playlist")

        val tracks = mutableListOf<ImportedTrack>()
        var url: String? =
            "https://api.spotify.com/v1/playlists/$pid/tracks?limit=100&fields=next,items(track(name,artists(name)))"
        while (url != null) {
            val j = JSONObject(http(url, auth))
            val items = j.getJSONArray("items")
            for (i in 0 until items.length()) {
                val t = items.getJSONObject(i).optJSONObject("track") ?: continue
                val artists = t.optJSONArray("artists")
                val artist = if (artists == null) "" else
                    (0 until artists.length()).joinToString(", ") { artists.getJSONObject(it).optString("name") }
                val title = t.optString("name")
                if (title.isNotBlank()) tracks += ImportedTrack(title, artist)
            }
            url = if (j.isNull("next")) null else j.optString("next").ifBlank { null }
        }
        return ImportedPlaylist(name, tracks)
    }

    // ---------- YouTube ----------
    fun youtube(link: String, apiKey: String): ImportedPlaylist {
        require(apiKey.isNotBlank()) { "Add your YouTube Data API key in Settings first." }
        val pid = Regex("[?&]list=([A-Za-z0-9_-]+)").find(link)?.groupValues?.get(1)
            ?: throw IllegalArgumentException("That doesn't look like a YouTube playlist link.")

        val name = JSONObject(
            http("https://www.googleapis.com/youtube/v3/playlists?part=snippet&id=$pid&key=${enc(apiKey)}")
        ).optJSONArray("items")?.optJSONObject(0)?.optJSONObject("snippet")?.optString("title")
            ?: "YouTube playlist"

        val tracks = mutableListOf<ImportedTrack>()
        var page: String? = null
        do {
            val u = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50" +
                "&playlistId=$pid&key=${enc(apiKey)}" + (page?.let { "&pageToken=$it" } ?: "")
            val j = JSONObject(http(u))
            val items = j.optJSONArray("items")
            if (items != null) for (i in 0 until items.length()) {
                val s = items.getJSONObject(i).optJSONObject("snippet") ?: continue
                val raw = s.optString("title")
                if (raw == "Deleted video" || raw == "Private video") continue
                val channel = s.optString("videoOwnerChannelTitle").removeSuffix(" - Topic")
                tracks += cleanYoutubeTitle(raw, channel)
            }
            page = j.optString("nextPageToken").ifBlank { null }
        } while (page != null)
        return ImportedPlaylist(name, tracks)
    }

    private fun cleanYoutubeTitle(raw: String, channel: String): ImportedTrack {
        val t = raw.replace(Regex("\\(.*?\\)|\\[.*?\\]"), "")
            .replace(Regex("(?i)official\\s+(music\\s+)?video|lyrics?|audio|hd|4k"), "")
            .trim()
        val parts = t.split(Regex("\\s[-–—]\\s"), limit = 2)
        return if (parts.size == 2) ImportedTrack(parts[1].trim(), parts[0].trim())
        else ImportedTrack(t, channel)
    }

    // ---------- Pasted text / CSV (JioSaavn and anything else) ----------
    fun parseText(raw: String): List<ImportedTrack> {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()

        val header = splitCsv(lines[0]).map { it.lowercase() }
        val titleIdx = header.indexOfFirst {
            it.contains("track name") || it == "title" || it == "song" || it == "track" || it == "name"
        }
        val artistIdx = header.indexOfFirst { it.contains("artist") }
        if (titleIdx >= 0 && artistIdx >= 0 && titleIdx != artistIdx) {
            return lines.drop(1).mapNotNull { l ->
                val row = splitCsv(l)
                val title = row.getOrNull(titleIdx).orEmpty()
                if (title.isBlank()) null
                else ImportedTrack(title, row.getOrNull(artistIdx).orEmpty().replace(";", ", "))
            }
        }
        return lines.map { l ->
            val parts = l.split(Regex("\\s[-–—]\\s|\t"), limit = 2)
            ImportedTrack(parts[0].trim(), parts.getOrNull(1)?.trim().orEmpty())
        }
    }

    private fun splitCsv(line: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var quoted = false
        for (ch in line) {
            when {
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { out += sb.toString().trim(); sb.clear() }
                else -> sb.append(ch)
            }
        }
        out += sb.toString().trim()
        return out
    }
}

/** Matches imported (title, artist) pairs to songs already on the device. */
class Matcher(pool: List<Song>) {
    private class Entry(val song: Song, val title: String, val artist: String)

    private val entries = pool.map { Entry(it, norm(it.title), norm(it.artist)) }

    fun find(track: ImportedTrack): Song? {
        val nt = norm(track.title)
        val na = norm(track.artist)
        if (nt.isBlank()) return null
        var best: Song? = null
        var bestScore = 0
        for (e in entries) {
            var score = when {
                e.title == nt -> 3
                nt.length >= 4 && e.title.length >= 4 && (e.title.contains(nt) || nt.contains(e.title)) -> 2
                else -> continue
            }
            if (na.isNotBlank() &&
                (e.artist.contains(na) || na.split(' ').any { it.length > 2 && e.artist.contains(it) })
            ) score += 1
            if (score > bestScore) { bestScore = score; best = e.song }
        }
        return if (bestScore >= 3 || (bestScore >= 2 && na.isBlank())) best else null
    }

    companion object {
        fun norm(s: String): String = s.lowercase()
            .replace(Regex("\\(.*?\\)|\\[.*?\\]"), " ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }
}
