package com.scg.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.scg.player.PlayerUiState
import com.scg.player.ScgViewModel
import com.scg.player.Song

/** Full-screen "Now Playing" in the style of Apple Music. */
@Composable
fun NowPlayingScreen(
    vm: ScgViewModel,
    song: Song,
    ui: PlayerUiState,
    liked: Boolean,
    onClose: () -> Unit,
    onOpenEq: () -> Unit,
) {
    val pal = LocalPalette.current
    BackHandler(onBack = onClose)

    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val duration = ui.durationMs.coerceAtLeast(1L)
    val position = if (dragging) dragValue else ui.positionMs.toFloat()
    val scale by animateFloatAsState(if (ui.isPlaying) 1f else 0.84f, tween(350), label = "artScale")

    Box(
        Modifier.fillMaxSize().background(pal.brush)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f)))))

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.padding(top = 10.dp, bottom = 8.dp).size(width = 44.dp, height = 5.dp)
                    .clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = 0.45f))
                    .clickable(onClick = onClose)
            )
            Spacer(Modifier.weight(1f))

            Artwork(
                song,
                Modifier.fillMaxWidth().aspectRatio(1f)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .shadow(28.dp, RoundedCornerShape(20.dp)),
                corner = 20.dp
            )

            Spacer(Modifier.weight(1f))

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = Color.White.copy(alpha = 0.7f), fontSize = 18.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(
                    onClick = { vm.toggleLike(song.key) },
                    modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.15f))
                ) {
                    Icon(
                        if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like",
                        tint = if (liked) pal.accent else Color.White
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Slider(
                value = position.coerceIn(0f, duration.toFloat()),
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = { vm.seekTo(dragValue.toLong()); dragging = false },
                valueRange = 0f..duration.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = Color.White, activeTrackColor = Color.White,
                    inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(position.toLong()), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                Text("-" + formatTime(duration - position.toLong()), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
            }

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(vm::previous, Modifier.size(64.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(44.dp))
                }
                IconButton(vm::togglePlay, Modifier.size(88.dp)) {
                    Icon(if (ui.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        if (ui.isPlaying) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(68.dp))
                }
                IconButton(vm::next, Modifier.size(64.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(44.dp))
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton(vm::toggleShuffle) {
                    Icon(Icons.Default.Shuffle, "Shuffle",
                        tint = if (ui.shuffle) pal.accent else Color.White.copy(alpha = 0.7f))
                }
                IconButton(onOpenEq) {
                    Icon(Icons.Default.Equalizer, "Equalizer", tint = Color.White.copy(alpha = 0.85f))
                }
                IconButton(vm::cycleRepeat) {
                    Icon(
                        if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "Repeat",
                        tint = if (ui.repeatMode != Player.REPEAT_MODE_OFF) pal.accent else Color.White.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}
