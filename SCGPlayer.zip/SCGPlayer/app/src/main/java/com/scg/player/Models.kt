package com.scg.player

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import java.io.File

/** key = "local:<mediaStoreId>" or "dl:<uuid>" — stable id used for likes and playlists. */
data class Song(
    val key: String,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val albumId: Long = -1,
    val downloaded: Boolean = false,
)

data class Playlist(
    val id: String,
    val name: String,
    val keys: List<String>,
    /** Imported tracks that were not found in the library, shown as "Title — Artist". */
    val missing: List<String> = emptyList(),
)

data class DownloadItem(
    val id: String,
    val title: String,
    val artist: String,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long,
)

fun DownloadItem.toSong() = Song(
    key = "dl:$id",
    title = title,
    artist = artist.ifBlank { "Unknown artist" },
    album = "Downloads",
    durationMs = durationMs,
    uri = Uri.fromFile(File(path)),
    downloaded = true,
)

fun Song.toMediaItem(): MediaItem {
    val md = MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album)
    if (albumId >= 0) md.setArtworkUri(Uri.parse("content://media/external/audio/albumart/$albumId"))
    return MediaItem.Builder().setMediaId(key).setUri(uri).setMediaMetadata(md.build()).build()
}

data class ImportedTrack(val title: String, val artist: String)
data class ImportedPlaylist(val name: String, val tracks: List<ImportedTrack>)

data class Creds(
    val spotifyId: String = "",
    val spotifySecret: String = "",
    val youtubeKey: String = "",
)
