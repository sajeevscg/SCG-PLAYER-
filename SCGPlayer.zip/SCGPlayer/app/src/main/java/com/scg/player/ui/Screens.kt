package com.scg.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.scg.player.*

@Composable
private fun CenterMessage(text: String, action: String? = null, onClick: () -> Unit = {}) {
    Column(
        Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text, color = Color.White.copy(alpha = 0.75f))
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick) { Text(action) }
        }
    }
}

// ============================ Library ============================
@Composable
fun LibraryScreen(
    vm: ScgViewModel,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onAddToPlaylist: (Song) -> Unit,
) {
    val songs by vm.library.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val liked by vm.liked.collectAsStateWithLifecycle()
    val likedSet = remember(liked) { liked.toSet() }
    var query by remember { mutableStateOf("") }
    val filtered = remember(songs, query) {
        if (query.isBlank()) songs
        else songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Library")
        OutlinedTextField(
            query, { query = it },
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Songs or artists") },
            singleLine = true, shape = RoundedCornerShape(14.dp)
        )
        PlayShuffleRow({ vm.playQueue(filtered, 0) }, { vm.shuffleQueue(filtered) })
        LazyColumn(Modifier.weight(1f)) {
            if (!hasPermission && songs.isEmpty()) {
                item { CenterMessage("Allow access to your audio files to see your music.", "Grant access", onRequestPermission) }
            } else if (filtered.isEmpty()) {
                item { CenterMessage(if (songs.isEmpty()) "No music found on this device." else "No matches.") }
            }
            itemsIndexed(filtered, key = { _, s -> s.key }) { i, s ->
                SongRow(
                    s, s.key == ui.currentKey, s.key in likedSet,
                    onClick = { vm.playQueue(filtered, i) },
                    onLike = { vm.toggleLike(s.key) },
                    onAddToPlaylist = { onAddToPlaylist(s) }
                )
            }
        }
    }
}

// ============================ Playlists ============================
@Composable
private fun GradientTile(icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    val pal = LocalPalette.current
    Box(
        modifier.clip(RoundedCornerShape(8.dp)).background(Brush.linearGradient(listOf(pal.top, pal.accent))),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.fillMaxSize(0.5f)) }
}

@Composable
private fun PlaylistRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GradientTile(icon, Modifier.size(56.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color.White.copy(alpha = 0.65f), fontSize = 13.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color.White.copy(alpha = 0.5f))
    }
}

@Composable
fun PlaylistsScreen(vm: ScgViewModel, onAddToPlaylist: (Song) -> Unit, onImport: () -> Unit) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val library by vm.library.collectAsStateWithLifecycle()
    val liked by vm.liked.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val likedSet = remember(liked) { liked.toSet() }
    val byKey = remember(library) { library.associateBy { it.key } }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }

    if (showCreate) CreatePlaylistDialog({ showCreate = false }) { vm.createPlaylist(it); showCreate = false }

    val id = openId
    val pl = playlists.firstOrNull { it.id == id }
    if (id != null && (id == "liked" || pl != null)) {
        BackHandler { openId = null }
        val isLiked = id == "liked"
        val title = if (isLiked) "Liked Songs" else pl!!.name
        val keys = if (isLiked) liked else pl!!.keys
        val songs = remember(keys, byKey) { keys.mapNotNull { byKey[it] } }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(top = 8.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ openId = null }) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
                Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f), maxLines = 1)
                if (!isLiked) IconButton({ vm.deletePlaylist(id); openId = null }) {
                    Icon(Icons.Default.Delete, "Delete playlist", tint = Color.White.copy(alpha = 0.8f))
                }
            }
            PlayShuffleRow({ vm.playQueue(songs, 0) }, { vm.shuffleQueue(songs) })
            LazyColumn(Modifier.weight(1f)) {
                if (songs.isEmpty()) item { CenterMessage("No songs yet. Use ⋮ → Add to playlist on any song.") }
                itemsIndexed(songs, key = { _, s -> s.key }) { i, s ->
                    SongRow(
                        s, s.key == ui.currentKey, s.key in likedSet,
                        onClick = { vm.playQueue(songs, i) },
                        onLike = { vm.toggleLike(s.key) },
                        onAddToPlaylist = { onAddToPlaylist(s) },
                        onRemove = { if (isLiked) vm.toggleLike(s.key) else vm.removeFromPlaylist(id, s.key) },
                        removeLabel = if (isLiked) "Unlike" else "Remove from playlist"
                    )
                }
                if (pl != null && pl.missing.isNotEmpty()) {
                    item { SectionLabel("Not on this device (${pl.missing.size})") }
                    items(pl.missing) { m ->
                        Text(m, color = Color.White.copy(alpha = 0.55f), fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
                    }
                }
            }
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScreenTitle("Playlists", Modifier.weight(1f))
            IconButton(onImport) { Icon(Icons.Default.FileDownload, "Import", tint = Color.White) }
            IconButton({ showCreate = true }) { Icon(Icons.Default.Add, "New playlist", tint = Color.White) }
            Spacer(Modifier.width(8.dp))
        }
        LazyColumn(Modifier.weight(1f)) {
            item { PlaylistRow("Liked Songs", "${liked.size} songs", Icons.Default.Favorite) { openId = "liked" } }
            items(playlists, key = { it.id }) { p ->
                PlaylistRow(p.name, "${p.keys.size} songs" + if (p.missing.isNotEmpty()) " • ${p.missing.size} missing" else "",
                    Icons.Default.QueueMusic) { openId = p.id }
            }
            if (playlists.isEmpty()) item {
                CenterMessage("Create a playlist with +, or import one from Spotify, YouTube or JioSaavn with the import button.")
            }
        }
    }
}

// ============================ Downloads ============================
@Composable
fun DownloadsScreen(vm: ScgViewModel, onAddToPlaylist: (Song) -> Unit) {
    val songs by vm.downloadedSongs.collectAsStateWithLifecycle()
    val dl by vm.downloadState.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val liked by vm.liked.collectAsStateWithLifecycle()
    val likedSet = remember(liked) { liked.toSet() }
    var showAdd by remember { mutableStateOf(false) }

    if (showAdd) DownloadDialog({ showAdd = false }) { u, t, a -> vm.download(u, t, a); showAdd = false }

    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScreenTitle("Downloads", Modifier.weight(1f))
            IconButton({ showAdd = true }) { Icon(Icons.Default.Add, "Download", tint = Color.White) }
            Spacer(Modifier.width(8.dp))
        }
        when (val s = dl) {
            is DownloadState.Running -> Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                Text("Downloading ${s.title}…", color = Color.White)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(progress = { s.progress }, Modifier.fillMaxWidth())
            }
            is DownloadState.Failed -> Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(s.message, color = Color(0xFFFF8A80), modifier = Modifier.weight(1f), fontSize = 13.sp)
                TextButton(vm::clearDownloadError) { Text("Dismiss") }
            }
            else -> {}
        }
        if (songs.isNotEmpty()) PlayShuffleRow({ vm.playQueue(songs, 0) }, { vm.shuffleQueue(songs) })
        LazyColumn(Modifier.weight(1f)) {
            if (songs.isEmpty()) item {
                CenterMessage("Downloaded songs play without internet. Tap + and paste a direct https link to an audio file you're allowed to download.")
            }
            itemsIndexed(songs, key = { _, s -> s.key }) { i, s ->
                SongRow(
                    s, s.key == ui.currentKey, s.key in likedSet,
                    onClick = { vm.playQueue(songs, i) },
                    onLike = { vm.toggleLike(s.key) },
                    onAddToPlaylist = { onAddToPlaylist(s) },
                    onRemove = { vm.deleteDownload(s) },
                    removeLabel = "Delete download"
                )
            }
        }
    }
}

// ============================ Settings ============================
@Composable
fun SettingsScreen(vm: ScgViewModel, onOpenEq: () -> Unit) {
    val themeIdx by vm.themeIndex.collectAsStateWithLifecycle()
    val creds by vm.creds.collectAsStateWithLifecycle()
    var sid by remember(creds) { mutableStateOf(creds.spotifyId) }
    var ssec by remember(creds) { mutableStateOf(creds.spotifySecret) }
    var ykey by remember(creds) { mutableStateOf(creds.youtubeKey) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenTitle("Settings")

        SectionLabel("Gradient theme")
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
            ScgPalettes.forEachIndexed { i, p ->
                Column(
                    Modifier.clickable { vm.setTheme(i) }.padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(60.dp).clip(CircleShape).background(p.brush)
                            .then(if (i == themeIdx) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(p.name, color = Color.White, fontSize = 12.sp)
                }
            }
        }

        SectionLabel("Sound")
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onOpenEq).padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Equalizer, null, tint = Color.White)
            Spacer(Modifier.width(16.dp))
            Text("Equalizer", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null, tint = Color.White.copy(alpha = 0.5f))
        }

        SectionLabel("Playlist import keys (optional)")
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Spotify and YouTube imports use their official APIs with your own keys, stored only on this phone.",
                color = Color.White.copy(alpha = 0.65f), fontSize = 13.sp
            )
            OutlinedTextField(sid, { sid = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Spotify Client ID") })
            OutlinedTextField(ssec, { ssec = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Spotify Client Secret") }, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(ykey, { ykey = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("YouTube Data API key") }, visualTransformation = PasswordVisualTransformation())
            Button({ vm.saveCreds(Creds(sid.trim(), ssec.trim(), ykey.trim())) }) { Text("Save keys") }
        }
        Spacer(Modifier.height(24.dp))
    }
}
