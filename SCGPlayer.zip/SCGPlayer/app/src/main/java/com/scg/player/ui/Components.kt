package com.scg.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scg.player.PlayerUiState
import com.scg.player.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val artCache = LruCache<String, Bitmap>(80)

private fun loadArt(ctx: Context, s: Song): Bitmap? = runCatching {
    when {
        s.downloaded -> {
            val r = MediaMetadataRetriever()
            r.setDataSource(s.uri.path)
            val bytes = r.embeddedPicture
            r.release()
            bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        }
        Build.VERSION.SDK_INT >= 29 -> ctx.contentResolver.loadThumbnail(s.uri, Size(512, 512), null)
        else -> ctx.contentResolver
            .openInputStream(Uri.parse("content://media/external/audio/albumart/${s.albumId}"))
            ?.use { BitmapFactory.decodeStream(it) }
    }
}.getOrNull()

/** Album art, falling back to a gradient tile with a note icon. */
@Composable
fun Artwork(song: Song?, modifier: Modifier = Modifier, corner: Dp = 8.dp) {
    val ctx = LocalContext.current
    val pal = LocalPalette.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, song?.key) {
        value = if (song == null) null else {
            artCache.get(song.key)?.asImageBitmap() ?: withContext(Dispatchers.IO) {
                loadArt(ctx, song)?.also { artCache.put(song.key, it) }?.asImageBitmap()
            }
        }
    }
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(pal.top, pal.accent))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.fillMaxSize(0.45f))
        }
    }
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold,
        modifier = modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp)
    )
}

@Composable
fun PlayShuffleRow(onPlay: () -> Unit, onShuffle: () -> Unit) {
    val pal = LocalPalette.current
    val colors = ButtonDefaults.buttonColors(
        containerColor = Color.White.copy(alpha = 0.16f), contentColor = pal.accent
    )
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onPlay, Modifier.weight(1f), colors = colors, shape = RoundedCornerShape(12.dp)) {
            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Play")
        }
        Button(onShuffle, Modifier.weight(1f), colors = colors, shape = RoundedCornerShape(12.dp)) {
            Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Shuffle")
        }
    }
}

@Composable
fun SongRow(
    song: Song,
    current: Boolean,
    liked: Boolean,
    onClick: () -> Unit,
    onLike: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemove: (() -> Unit)? = null,
    removeLabel: String = "Remove",
) {
    val pal = LocalPalette.current
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(song, Modifier.size(52.dp), 8.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = if (current) pal.accent else Color.White, fontSize = 16.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                song.artist + if (song.downloaded) "  •  Offline" else "",
                color = Color.White.copy(alpha = 0.65f), fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onLike) {
            Icon(
                if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like",
                tint = if (liked) pal.accent else Color.White.copy(alpha = 0.7f)
            )
        }
        Box {
            IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "More", tint = Color.White.copy(alpha = 0.7f)) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Add to playlist") },
                    leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                    onClick = { menu = false; onAddToPlaylist() }
                )
                if (onRemove != null) {
                    DropdownMenuItem(
                        text = { Text(removeLabel) },
                        leadingIcon = { Icon(Icons.Default.Delete, null) },
                        onClick = { menu = false; onRemove() }
                    )
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(song: Song, ui: PlayerUiState, onToggle: () -> Unit, onNext: () -> Unit, onOpen: () -> Unit) {
    val pal = LocalPalette.current
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    Surface(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color.Black.copy(alpha = 0.5f)
    ) {
        Column {
            Row(Modifier.clickable(onClick = onOpen).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(song, Modifier.size(44.dp), 8.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onToggle) {
                    Icon(if (ui.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause",
                        tint = Color.White, modifier = Modifier.size(30.dp))
                }
                IconButton(onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(30.dp)) }
            }
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = pal.accent, trackColor = Color.Transparent
            )
        }
    }
}
