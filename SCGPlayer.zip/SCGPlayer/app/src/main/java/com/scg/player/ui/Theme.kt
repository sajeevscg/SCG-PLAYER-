package com.scg.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** A gradient theme: three background stops + one accent colour. */
data class ScgPalette(
    val name: String,
    val top: Color,
    val mid: Color,
    val bottom: Color,
    val accent: Color,
) {
    val brush: Brush get() = Brush.verticalGradient(listOf(top, mid, bottom))
}

val ScgPalettes = listOf(
    ScgPalette("Sunset", Color(0xFFD9480F), Color(0xFF9D174D), Color(0xFF1A0B1F), Color(0xFFFF8A5B)),
    ScgPalette("Ocean", Color(0xFF0369A1), Color(0xFF1E3A8A), Color(0xFF020617), Color(0xFF38BDF8)),
    ScgPalette("Aurora", Color(0xFF0F766E), Color(0xFF6D28D9), Color(0xFF0A0A1F), Color(0xFF5EEAD4)),
    ScgPalette("Rose", Color(0xFFBE123C), Color(0xFF701A75), Color(0xFF12060C), Color(0xFFFB7185)),
    ScgPalette("Midnight", Color(0xFF3730A3), Color(0xFF1E1B4B), Color(0xFF000000), Color(0xFFA5B4FC)),
)

val LocalPalette = staticCompositionLocalOf { ScgPalettes[0] }

val DarkSurface = Color(0xFF1F1F23)

@Composable
fun ScgAppTheme(palette: ScgPalette, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = palette.accent,
            onPrimary = Color.Black,
            secondary = palette.accent,
            tertiary = palette.accent,
        ),
        content = content,
    )
}
