package com.scg.player

import android.content.SharedPreferences
import android.media.AudioManager
import android.media.audiofx.Equalizer
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

object EqProtocol {
    const val ACTION = "scg.eq"
    val command = SessionCommand(ACTION, Bundle.EMPTY)
}

/** Background playback + media notification + system Equalizer attached to the player. */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var eq: Equalizer? = null
    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("scg_eq", MODE_PRIVATE)
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val sid = am.generateAudioSessionId()
        if (sid > 0) player.audioSessionId = sid
        attachEq(player.audioSessionId)
        player.addListener(object : Player.Listener {
            // not used; session id is fixed above, but keep EQ attached if it ever changes
        })
        session = MediaSession.Builder(this, player).setCallback(Callback()).build()
    }

    private fun attachEq(sessionId: Int) {
        eq?.release()
        eq = null
        if (sessionId == C.AUDIO_SESSION_ID_UNSET) return
        runCatching {
            val e = Equalizer(0, sessionId)
            val n = e.numberOfBands.toInt()
            val saved = prefs.getString("levels", null)?.split(",")?.mapNotNull { it.toShortOrNull() }
            if (saved != null && saved.size == n) saved.forEachIndexed { i, l -> e.setBandLevel(i.toShort(), l) }
            e.setEnabled(prefs.getBoolean("enabled", false))
            eq = e
        }
    }

    private fun applyEq(args: Bundle) {
        val e = eq ?: return
        val n = e.numberOfBands.toInt()
        if (args.containsKey("enabled")) e.setEnabled(args.getBoolean("enabled"))
        if (args.containsKey("preset")) e.usePreset(args.getInt("preset").toShort())
        if (args.containsKey("band")) e.setBandLevel(args.getInt("band").toShort(), args.getInt("level").toShort())
        if (args.getBoolean("reset", false)) for (i in 0 until n) e.setBandLevel(i.toShort(), 0)
        prefs.edit()
            .putBoolean("enabled", e.getEnabled())
            .putString("levels", (0 until n).joinToString(",") { e.getBandLevel(it.toShort()).toString() })
            .apply()
    }

    private fun eqInfo(): Bundle {
        val b = Bundle()
        val e = eq
        if (e == null) { b.putInt("bands", 0); return b }
        val n = e.numberOfBands.toInt()
        val range = e.bandLevelRange
        b.putInt("bands", n)
        b.putInt("min", range[0].toInt())
        b.putInt("max", range[1].toInt())
        b.putIntArray("freqs", IntArray(n) { e.getCenterFreq(it.toShort()) / 1000 })
        b.putIntArray("levels", IntArray(n) { e.getBandLevel(it.toShort()).toInt() })
        b.putBoolean("enabled", e.getEnabled())
        b.putStringArray("presets", Array(e.numberOfPresets.toInt()) { e.getPresetName(it.toShort()) })
        return b
    }

    private inner class Callback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                .add(EqProtocol.command).build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds).build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == EqProtocol.ACTION) {
                applyEq(args)
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS, eqInfo()))
            }
            return super.onCustomCommand(session, controller, customCommand, args)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        eq?.release()
        eq = null
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
