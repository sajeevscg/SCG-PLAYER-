package com.scg.player

import android.content.Context
import android.media.MediaMetadataRetriever
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Downloads a direct audio file (https) into app storage for offline playback.
 * Use it only for audio you have the right to download.
 */
object Downloader {
    private val audioExt = setOf("mp3", "m4a", "aac", "ogg", "wav", "flac", "opus")

    suspend fun download(
        context: Context,
        url: String,
        title: String,
        artist: String,
        onProgress: (Float) -> Unit,
    ): DownloadItem = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) throw IOException("Only https:// links are supported.")
        val dir = File(context.filesDir, "downloads").apply { mkdirs() }
        val id = UUID.randomUUID().toString()
        val ext = url.substringBefore('?').substringAfterLast('.', "").lowercase()
            .let { if (it in audioExt) it else "mp3" }
        val file = File(dir, "$id.$ext")
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            if (c.responseCode !in 200..299) throw IOException("Server returned HTTP ${c.responseCode}")
            if (c.contentType.orEmpty().startsWith("text/"))
                throw IOException("That link isn't a direct audio file.")
            val total = c.contentLengthLong
            var done = 0L
            var lastPct = -1
            c.inputStream.use { input ->
                file.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct) { lastPct = pct; onProgress(pct / 100f) }
                        }
                    }
                }
            }
            val dur = runCatching {
                val r = MediaMetadataRetriever()
                r.setDataSource(file.absolutePath)
                val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
                r.release()
                d
            }.getOrDefault(0L)
            DownloadItem(id, title.ifBlank { "Untitled" }, artist, file.absolutePath, dur, file.length())
        } catch (e: Throwable) {
            file.delete()
            throw e
        }
    }
}
