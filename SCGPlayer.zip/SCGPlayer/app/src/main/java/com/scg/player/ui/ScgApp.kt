package com.scg.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.scg.player.ScgViewModel
import com.scg.player.Song

@Composable
fun ScgApp(vm: ScgViewModel, hasPermission: Boolean, onRequestPermission: () -> Unit) {
    val themeIdx by vm.themeIndex.collectAsStateWithLifecycle()
    val palette = ScgPalettes[themeIdx.coerceIn(0, ScgPalettes.lastIndex)]
    val library by vm.library.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val liked by vm.liked.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    var showEq by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var addTarget by remember { mutableStateOf<Song?>(null) }

    val current = remember(ui.currentKey, library) { library.firstOrNull { it.key == ui.currentKey } }
    val tabs: List<Pair<String, ImageVector>> = listOf(
        "Library" to Icons.Default.LibraryMusic,
        "Playlists" to Icons.Default.QueueMusic,
        "Downloads" to Icons.Default.Download,
        "Settings" to Icons.Default.Settings,
    )

    CompositionLocalProvider(LocalPalette provides palette) {
        ScgAppTheme(palette) {
            Box(Modifier.fillMaxSize().background(palette.brush)) {
                Scaffold(
                    containerColor = Color.Transparent,
                    bottomBar = {
                        Column {
                            if (current != null) {
                                MiniPlayer(current, ui, vm::togglePlay, vm::next) { showPlayer = true }
                            }
                            NavigationBar(containerColor = Color.Black.copy(alpha = 0.35f)) {
                                tabs.forEachIndexed { i, (label, icon) ->
                                    NavigationBarItem(
                                        selected = tab == i,
                                        onClick = { tab = i },
                                        icon = { Icon(icon, label) },
                                        label = { Text(label) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = palette.accent,
                                            selectedTextColor = palette.accent,
                                            indicatorColor = Color.Transparent,
                                            unselectedIconColor = Color.White.copy(alpha = 0.6f),
                                            unselectedTextColor = Color.White.copy(alpha = 0.6f),
                                        )
                                    )
                                }
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad).fillMaxSize()) {
                        when (tab) {
                            0 -> LibraryScreen(vm, hasPermission, onRequestPermission) { addTarget = it }
                            1 -> PlaylistsScreen(vm, { addTarget = it }, { showImport = true })
                            2 -> DownloadsScreen(vm) { addTarget = it }
                            else -> SettingsScreen(vm) { showEq = true }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = showPlayer && current != null,
                    enter = slideInVertically { it },
                    exit = slideOutVertically { it },
                ) {
                    if (current != null) {
                        NowPlayingScreen(
                            vm, current, ui, current.key in liked,
                            onClose = { showPlayer = false },
                            onOpenEq = { showEq = true },
                        )
                    }
                }
            }

            addTarget?.let { s ->
                AddToPlaylistDialog(
                    song = s, playlists = playlists,
                    onDismiss = { addTarget = null },
                    onPick = { vm.addToPlaylist(it, s.key); addTarget = null },
                    onNew = { name -> vm.addToPlaylist(vm.createPlaylist(name), s.key); addTarget = null },
                )
            }
            if (showImport) ImportDialog(vm) { showImport = false }
            if (showEq) EqualizerSheet(vm) { showEq = false }
        }
    }
}
