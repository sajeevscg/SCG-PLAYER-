package com.scg.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.scg.player.*

@Composable
fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = DarkSurface,
        title = { Text("New playlist") },
        text = {
            OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("Playlist name") })
        },
        confirmButton = { TextButton({ onCreate(name) }, enabled = name.isNotBlank()) { Text("Create") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddToPlaylistDialog(
    song: Song,
    playlists: List<Playlist>,
    onDismiss: () -> Unit,
    onPick: (String) -> Unit,
    onNew: (String) -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        CreatePlaylistDialog(onDismiss = { creating = false }, onCreate = onNew)
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = DarkSurface,
        title = { Text("Add to playlist") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(
                    Modifier.fillMaxWidth().clickable { creating = true }.padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Text("New playlist…", color = MaterialTheme.colorScheme.primary)
                }
                playlists.forEach { pl ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(pl.id) }.padding(vertical = 12.dp)) {
                        Text(pl.name, Modifier.weight(1f))
                        Text(if (song.key in pl.keys) "Added" else "${pl.keys.size}", color = Color.White.copy(alpha = 0.55f))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("Close") } }
    )
}

@Composable
fun ImportDialog(vm: ScgViewModel, onDismiss: () -> Unit) {
    val state by vm.importState.collectAsStateWithLifecycle()
    val creds by vm.creds.collectAsStateWithLifecycle()
    var source by remember { mutableStateOf(ImportSource.SPOTIFY) }
    var input by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    DisposableEffect(Unit) { onDispose { vm.resetImport() } }

    val hint = when (source) {
        ImportSource.SPOTIFY -> "Paste a public Spotify playlist link. Needs your Spotify Client ID and Secret (Settings)."
        ImportSource.YOUTUBE -> "Paste a public YouTube playlist link. Needs your YouTube Data API key (Settings)."
        ImportSource.TEXT -> "JioSaavn has no public API. Paste your track list — one “Title - Artist” per line — or CSV text exported with a tool like TuneMyMusic or Exportify."
    }
    val missingKey = when (source) {
        ImportSource.SPOTIFY -> creds.spotifyId.isBlank() || creds.spotifySecret.isBlank()
        ImportSource.YOUTUBE -> creds.youtubeKey.isBlank()
        ImportSource.TEXT -> false
    }

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = DarkSurface,
        title = { Text("Import playlist") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(source == ImportSource.SPOTIFY, { source = ImportSource.SPOTIFY }, { Text("Spotify") })
                    FilterChip(source == ImportSource.YOUTUBE, { source = ImportSource.YOUTUBE }, { Text("YouTube") })
                    FilterChip(source == ImportSource.TEXT, { source = ImportSource.TEXT }, { Text("JioSaavn / list") })
                }
                Spacer(Modifier.height(10.dp))
                Text(hint, fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
                if (missingKey) {
                    Spacer(Modifier.height(6.dp))
                    Text("API key missing — add it in Settings.", fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    input, { input = it }, Modifier.fillMaxWidth(),
                    placeholder = { Text(if (source == ImportSource.TEXT) "Paste tracks here" else "Playlist link") },
                    minLines = if (source == ImportSource.TEXT) 5 else 1,
                    maxLines = if (source == ImportSource.TEXT) 8 else 2,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Playlist name (optional)") })
                Spacer(Modifier.height(12.dp))
                when (val s = state) {
                    is ImportState.Running -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp)); Text("Importing and matching…")
                    }
                    is ImportState.Failed -> Text(s.message, color = Color(0xFFFF8A80), fontSize = 13.sp)
                    is ImportState.Done -> Column {
                        Text("“${s.name}” created — matched ${s.matched} of ${s.total} tracks with songs on your phone.",
                            color = MaterialTheme.colorScheme.primary)
                        if (s.missing.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Not found on this device:", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                            s.missing.take(8).forEach { Text("• $it", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)) }
                            if (s.missing.size > 8) Text("…and ${s.missing.size - 8} more (saved in the playlist)", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                        }
                    }
                    else -> {}
                }
            }
        },
        confirmButton = {
            if (state is ImportState.Done) TextButton(onDismiss) { Text("Done") }
            else TextButton(
                { vm.importPlaylist(source, input, name) },
                enabled = input.isNotBlank() && state !is ImportState.Running
            ) { Text("Import") }
        },
        dismissButton = { if (state !is ImportState.Done) TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun DownloadDialog(onDismiss: () -> Unit, onStart: (url: String, title: String, artist: String) -> Unit) {
    var url by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = DarkSurface,
        title = { Text("Download for offline") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Paste a direct https link to an audio file (.mp3, .m4a, …) that you have the right to download. " +
                        "Streaming-service links (Spotify, YouTube, JioSaavn) can't be downloaded.",
                    fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://…/song.mp3") })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Title") })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(artist, { artist = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Artist") })
            }
        },
        confirmButton = {
            TextButton({ onStart(url, title, artist) }, enabled = url.startsWith("https://") && title.isNotBlank()) { Text("Download") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(vm: ScgViewModel, onDismiss: () -> Unit) {
    val eq by vm.eq.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.refreshEq() }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = DarkSurface) {
        Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Equalizer", fontSize = 22.sp, modifier = Modifier.weight(1f))
                Switch(eq.enabled, vm::setEqEnabled, enabled = eq.available)
            }
            if (!eq.available) {
                Spacer(Modifier.height(12.dp))
                Text("Equalizer isn't available yet. Start playing a song and reopen this panel.",
                    color = Color.White.copy(alpha = 0.7f))
                return@Column
            }
            if (eq.presets.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    eq.presets.forEachIndexed { i, name ->
                        AssistChip(onClick = { vm.setEqPreset(i) }, label = { Text(name) }, enabled = eq.enabled)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            eq.freqsHz.forEachIndexed { i, hz ->
                val label = if (hz >= 1000) "%.1f kHz".format(hz / 1000f) else "$hz Hz"
                val level = eq.levels.getOrElse(i) { 0 }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, Modifier.width(64.dp), fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                    Slider(
                        value = level.toFloat(),
                        onValueChange = { vm.setEqBand(i, it.toInt()) },
                        valueRange = eq.minLevel.toFloat()..eq.maxLevel.toFloat(),
                        enabled = eq.enabled,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${level / 100} dB", Modifier.width(52.dp), fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
                }
            }
            TextButton(vm::resetEq, enabled = eq.enabled) { Text("Reset to flat") }
        }
    }
}
