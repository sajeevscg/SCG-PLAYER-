package com.scg.player

import android.app.Application
import android.content.ComponentName
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class PlayerUiState(
    val currentKey: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
)

data class EqState(
    val available: Boolean = false,
    val enabled: Boolean = false,
    val minLevel: Int = 0,
    val maxLevel: Int = 0,
    val freqsHz: List<Int> = emptyList(),
    val levels: List<Int> = emptyList(),
    val presets: List<String> = emptyList(),
)

enum class ImportSource { SPOTIFY, YOUTUBE, TEXT }

sealed interface ImportState {
    data object Idle : ImportState
    data object Running : ImportState
    data class Done(val name: String, val matched: Int, val total: Int, val missing: List<String>) : ImportState
    data class Failed(val message: String) : ImportState
}

sealed interface DownloadState {
    data object Idle : DownloadState
    data class Running(val title: String, val progress: Float) : DownloadState
    data class Failed(val message: String) : DownloadState
}

class ScgViewModel(app: Application) : AndroidViewModel(app) {

    private val store = LibraryStore(app)
    private val mainExecutor = ContextCompat.getMainExecutor(app)
    private var controller: MediaController? = null

    private val localSongs = MutableStateFlow<List<Song>>(emptyList())
    val downloads = MutableStateFlow(store.downloads())
    val liked = MutableStateFlow(store.liked())
    val playlists = MutableStateFlow(store.playlists())
    val themeIndex = MutableStateFlow(store.themeIndex())
    val creds = MutableStateFlow(store.creds())

    private val _ui = MutableStateFlow(PlayerUiState())
    val ui: StateFlow<PlayerUiState> = _ui.asStateFlow()
    private val _eq = MutableStateFlow(EqState())
    val eq: StateFlow<EqState> = _eq.asStateFlow()
    private val _import = MutableStateFlow<ImportState>(ImportState.Idle)
    val importState: StateFlow<ImportState> = _import.asStateFlow()
    private val _dl = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState: StateFlow<DownloadState> = _dl.asStateFlow()

    val downloadedSongs: StateFlow<List<Song>> = downloads
        .map { list -> list.map { it.toSong() } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Everything playable: downloads first, then the device library. */
    val library: StateFlow<List<Song>> = combine(localSongs, downloadedSongs) { a, b -> b + a }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            c.addListener(listener)
            sync(c)
            refreshEq()
        }, mainExecutor)

        viewModelScope.launch {
            while (isActive) {
                controller?.let { c ->
                    if (c.isPlaying) _ui.update { it.copy(positionMs = c.currentPosition) }
                }
                delay(500)
            }
        }
    }

    fun loadSongs() {
        viewModelScope.launch { localSongs.value = MusicRepository.loadSongs(getApplication()) }
    }

    private fun sync(p: Player) {
        _ui.update {
            it.copy(
                currentKey = p.currentMediaItem?.mediaId,
                isPlaying = p.isPlaying,
                positionMs = p.currentPosition,
                durationMs = p.duration.coerceAtLeast(0),
                shuffle = p.shuffleModeEnabled,
                repeatMode = p.repeatMode,
            )
        }
    }

    // ---------------- Playback ----------------
    fun playQueue(songs: List<Song>, index: Int, shuffle: Boolean = false) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        c.shuffleModeEnabled = shuffle
        c.setMediaItems(songs.map { it.toMediaItem() }, index.coerceIn(songs.indices), 0L)
        c.prepare()
        c.play()
    }

    fun shuffleQueue(songs: List<Song>) {
        if (songs.isNotEmpty()) playQueue(songs, songs.indices.random(), shuffle = true)
    }

    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    // ---------------- Likes & playlists ----------------
    fun toggleLike(key: String) {
        val cur = liked.value
        val next = if (key in cur) cur - key else listOf(key) + cur
        liked.value = next
        store.saveLiked(next)
    }

    private fun setPlaylists(list: List<Playlist>) {
        playlists.value = list
        store.savePlaylists(list)
    }

    fun createPlaylist(name: String): String {
        val id = UUID.randomUUID().toString()
        setPlaylists(playlists.value + Playlist(id, name.trim().ifBlank { "New playlist" }, emptyList()))
        return id
    }

    fun deletePlaylist(id: String) = setPlaylists(playlists.value.filterNot { it.id == id })

    fun addToPlaylist(id: String, key: String) = setPlaylists(playlists.value.map {
        if (it.id == id && key !in it.keys) it.copy(keys = it.keys + key) else it
    })

    fun removeFromPlaylist(id: String, key: String) = setPlaylists(playlists.value.map {
        if (it.id == id) it.copy(keys = it.keys - key) else it
    })

    // ---------------- Import ----------------
    fun importPlaylist(source: ImportSource, input: String, nameOverride: String) {
        if (_import.value is ImportState.Running) return
        _import.value = ImportState.Running
        viewModelScope.launch {
            try {
                val c = creds.value
                val pool = library.value
                val result = withContext(Dispatchers.IO) {
                    val imported = when (source) {
                        ImportSource.SPOTIFY -> Importer.spotify(input.trim(), c.spotifyId.trim(), c.spotifySecret.trim())
                        ImportSource.YOUTUBE -> Importer.youtube(input.trim(), c.youtubeKey.trim())
                        ImportSource.TEXT -> ImportedPlaylist("Imported playlist", Importer.parseText(input))
                    }
                    if (imported.tracks.isEmpty()) throw IllegalStateException("No tracks found.")
                    val matcher = Matcher(pool)
                    val keys = LinkedHashSet<String>()
                    val missing = mutableListOf<String>()
                    for (t in imported.tracks) {
                        val m = matcher.find(t)
                        if (m != null) keys += m.key
                        else missing += if (t.artist.isBlank()) t.title else "${t.title} — ${t.artist}"
                    }
                    Triple(imported, keys.toList(), missing)
                }
                val (imported, keys, missing) = result
                val name = nameOverride.trim().ifBlank { imported.name }
                setPlaylists(playlists.value + Playlist(UUID.randomUUID().toString(), name, keys, missing))
                _import.value = ImportState.Done(name, keys.size, imported.tracks.size, missing)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _import.value = ImportState.Failed(e.message ?: "Import failed.")
            }
        }
    }

    fun resetImport() { _import.value = ImportState.Idle }

    // ---------------- Downloads ----------------
    fun download(url: String, title: String, artist: String) {
        if (_dl.value is DownloadState.Running) return
        val t = title.trim().ifBlank { "Untitled" }
        _dl.value = DownloadState.Running(t, 0f)
        viewModelScope.launch {
            try {
                val item = Downloader.download(getApplication(), url.trim(), t, artist.trim()) { p ->
                    _dl.value = DownloadState.Running(t, p)
                }
                val list = downloads.value + item
                downloads.value = list
                store.saveDownloads(list)
                _dl.value = DownloadState.Idle
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _dl.value = DownloadState.Failed(e.message ?: "Download failed.")
            }
        }
    }

    fun clearDownloadError() { _dl.value = DownloadState.Idle }

    fun deleteDownload(song: Song) {
        val id = song.key.removePrefix("dl:")
        val item = downloads.value.firstOrNull { it.id == id } ?: return
        File(item.path).delete()
        val list = downloads.value - item
        downloads.value = list
        store.saveDownloads(list)
    }

    // ---------------- Theme & credentials ----------------
    fun setTheme(i: Int) { themeIndex.value = i; store.saveTheme(i) }
    fun saveCreds(c: Creds) { creds.value = c; store.saveCreds(c) }

    // ---------------- Equalizer ----------------
    fun refreshEq() = sendEq(Bundle())
    fun setEqEnabled(on: Boolean) = sendEq(Bundle().apply { putBoolean("enabled", on) })
    fun setEqPreset(i: Int) = sendEq(Bundle().apply { putInt("preset", i) })
    fun resetEq() = sendEq(Bundle().apply { putBoolean("reset", true) })

    fun setEqBand(i: Int, level: Int) {
        _eq.update { s ->
            s.copy(levels = s.levels.toMutableList().also { if (i in it.indices) it[i] = level })
        }
        sendEq(Bundle().apply { putInt("band", i); putInt("level", level) }, applyReply = false)
    }

    private fun sendEq(args: Bundle, applyReply: Boolean = true) {
        val c = controller ?: return
        val f = c.sendCustomCommand(EqProtocol.command, args)
        if (!applyReply) return
        f.addListener({
            runCatching { parseEq(f.get().extras) }
        }, mainExecutor)
    }

    private fun parseEq(b: Bundle) {
        if (b.getInt("bands", 0) == 0) { _eq.value = EqState(); return }
        _eq.value = EqState(
            available = true,
            enabled = b.getBoolean("enabled"),
            minLevel = b.getInt("min"),
            maxLevel = b.getInt("max"),
            freqsHz = b.getIntArray("freqs")?.toList().orEmpty(),
            levels = b.getIntArray("levels")?.toList().orEmpty(),
            presets = b.getStringArray("presets")?.toList().orEmpty(),
        )
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        super.onCleared()
    }
}
