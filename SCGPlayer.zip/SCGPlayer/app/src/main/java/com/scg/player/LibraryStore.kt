package com.scg.player

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Tiny JSON-in-SharedPreferences persistence for likes, playlists, downloads and settings. */
class LibraryStore(context: Context) {
    private val p = context.getSharedPreferences("scg_library", Context.MODE_PRIVATE)

    private fun JSONArray?.strings(): List<String> =
        if (this == null) emptyList() else List(length()) { getString(it) }

    fun liked(): List<String> = runCatching {
        JSONArray(p.getString("liked", "[]")).strings()
    }.getOrDefault(emptyList())

    fun saveLiked(keys: List<String>) {
        p.edit().putString("liked", JSONArray(keys).toString()).apply()
    }

    fun playlists(): List<Playlist> = runCatching {
        val a = JSONArray(p.getString("playlists", "[]"))
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            Playlist(
                o.getString("id"), o.getString("name"),
                o.optJSONArray("keys").strings(), o.optJSONArray("missing").strings()
            )
        }
    }.getOrDefault(emptyList())

    fun savePlaylists(list: List<Playlist>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("id", it.id).put("name", it.name)
                    .put("keys", JSONArray(it.keys)).put("missing", JSONArray(it.missing))
            )
        }
        p.edit().putString("playlists", a.toString()).apply()
    }

    fun downloads(): List<DownloadItem> = runCatching {
        val a = JSONArray(p.getString("downloads", "[]"))
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            DownloadItem(
                o.getString("id"), o.getString("title"), o.optString("artist"),
                o.getString("path"), o.optLong("dur"), o.optLong("size")
            )
        }
    }.getOrDefault(emptyList())

    fun saveDownloads(list: List<DownloadItem>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("id", it.id).put("title", it.title).put("artist", it.artist)
                    .put("path", it.path).put("dur", it.durationMs).put("size", it.sizeBytes)
            )
        }
        p.edit().putString("downloads", a.toString()).apply()
    }

    fun themeIndex(): Int = p.getInt("theme", 0)
    fun saveTheme(i: Int) { p.edit().putInt("theme", i).apply() }

    fun creds() = Creds(
        p.getString("sp_id", "").orEmpty(),
        p.getString("sp_secret", "").orEmpty(),
        p.getString("yt_key", "").orEmpty(),
    )

    fun saveCreds(c: Creds) {
        p.edit().putString("sp_id", c.spotifyId).putString("sp_secret", c.spotifySecret)
            .putString("yt_key", c.youtubeKey).apply()
    }
}
