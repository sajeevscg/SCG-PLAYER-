# SCG PLAYER (Android)

Apple-Music-style local music player — Kotlin, Jetpack Compose, Media3.

Open this folder in Android Studio (Koala+), sync Gradle, run on Android 8.0+ (API 26).

## Features
- Apple-Music-style UI: bottom tabs, floating mini player, full-screen Now Playing with big artwork
- Background playback + notification / lock-screen controls (Media3 MediaSessionService)
- Playlists: create, add / remove songs, delete
- Liked songs (heart anywhere) + "Liked Songs" list
- Import playlists: Spotify & YouTube (official APIs, your own keys in Settings), JioSaavn / any app via pasted list or CSV.
  Tracks are matched to songs on the phone; unmatched ones are kept in the playlist as "Not on this device".
- Offline downloads: direct https audio links you have rights to; stored in the app and played offline
- 5 gradient themes (Sunset, Ocean, Aurora, Rose, Midnight)
- Equalizer: on/off, device presets, per-band sliders (system Equalizer on the player's audio session)

## Notes
- Spotify: create an app at developer.spotify.com for a Client ID/Secret. Only public playlists work, and
  Spotify may change API access rules.
- YouTube: create an API key (YouTube Data API v3) in Google Cloud Console.
- No audio is ever ripped from Spotify / YouTube / JioSaavn.
